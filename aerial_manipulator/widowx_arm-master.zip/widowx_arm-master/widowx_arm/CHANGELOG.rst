^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package widowx_arm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2016-11-23)
------------------

0.0.1 (2016-08-09)
------------------
* Modified package.xml
* Modified package.xml files
* Fist commit
* Contributors: RomanRobotnik, carlos3dx
