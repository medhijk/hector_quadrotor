^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package widowx_arm_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2016-11-23)
------------------
* modified cmakelists and package.xml
* DEL: urdf and xacro files
* MOD: changed launch
* NEW: renamed widowx_macro.xacro to widowx.urdf.xacro, created robots/widowx_arm.urdf.xacro
* Contributors: Jose Rapado, carlos3dx

0.0.1 (2016-08-09)
------------------
* Modified package.xml
* Modified package.xml files
* minor changes
* Adding move to gripper joint
* Adding widowx_arm_description
* Contributors: Jose Rapado, carlos3dx
