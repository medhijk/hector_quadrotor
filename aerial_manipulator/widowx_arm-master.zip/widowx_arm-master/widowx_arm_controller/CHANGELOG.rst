^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package widowx_arm_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2016-11-23)
------------------

0.0.1 (2016-08-09)
------------------
* Modified package.xml files
* minor changes
* Create README.md
* Fist commit
* Contributors: Jose Rapado, Roman Navarro Garcia, RomanRobotnik, carlos3dx
