#widowx_arm_controller

The WidowX Arm Controller is based on [arbotix_python](http://wiki.ros.org/arbotix_python) package

##Startup

`$ roslaunch widowx_arm_controller widowx_arm_controller.launch`
